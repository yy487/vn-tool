/*
 * lzss_fast.c - Overflow引擎 LZSS 压缩/解压 C加速模块
 * 修复: 匹配验证模拟解压器逐字节拷贝(重叠安全)
 * 编译: gcc -O2 -shared -fPIC -o lzss_fast.so lzss_fast.c
 */
#include <string.h>
#include <stdlib.h>

#define WINDOW_SIZE 4096
#define WINDOW_MASK 0xFFF
#define MAX_MATCH   18
#define MIN_MATCH   3
#define HASH_SIZE   4096
#define HASH_MASK   (HASH_SIZE - 1)
#define MAX_CHAIN   128

/* ============ 解压 ============ */
int lzss_decompress(const unsigned char *src, int src_len,
                    unsigned char *dst, int dst_len)
{
    unsigned char window[WINDOW_SIZE];
    memset(window, 0, sizeof(window));
    int wp = 0xFEE;
    int si = 0, di = 0;

    while (di < dst_len && si < src_len) {
        unsigned char flags = src[si++];
        int mask = 0x80;
        while (mask > 0 && di < dst_len && si < src_len) {
            if ((flags & mask) == 0) {
                unsigned char b = src[si++];
                dst[di++] = b;
                window[wp] = b;
                wp = (wp + 1) & WINDOW_MASK;
            } else {
                if (si + 1 >= src_len) break;
                int lo = src[si], hi = src[si+1];
                si += 2;
                int ref = lo | (hi << 8);
                int off = ref >> 4;
                int len = (ref & 0x0F) + 3;
                for (int j = 0; j < len && di < dst_len; j++) {
                    unsigned char b = window[(off + j) & WINDOW_MASK];
                    dst[di++] = b;
                    window[wp] = b;
                    wp = (wp + 1) & WINDOW_MASK;
                }
            }
            mask >>= 1;
        }
    }
    return di;
}

/* ============ 压缩 ============ */
static int head_tbl[HASH_SIZE];
static int chain_tbl[WINDOW_SIZE];

static inline int hash2(int a, int b) {
    return ((a << 4) ^ b) & HASH_MASK;
}

int lzss_compress(const unsigned char *src, int src_len,
                  unsigned char *dst, int dst_max)
{
    unsigned char window[WINDOW_SIZE];
    memset(window, 0, sizeof(window));
    memset(head_tbl, -1, sizeof(head_tbl));
    memset(chain_tbl, -1, sizeof(chain_tbl));

    int wp = 0xFEE;
    int si = 0, di = 0;
    int written = 0;

    while (si < src_len && di < dst_max - 20) {
        int flag_pos = di++;
        int flag_byte = 0;
        int mask = 0x80;

        while (mask > 0 && si < src_len && di < dst_max - 4) {
            int best_off = 0, best_len = 0;
            int max_m = src_len - si;
            if (max_m > MAX_MATCH) max_m = MAX_MATCH;

            if (max_m >= MIN_MATCH && si + 1 < src_len) {
                int h = hash2(src[si], src[si+1]);
                int pos = head_tbl[h];
                int attempts = 0;
                int w_limit = written < WINDOW_SIZE ? written : WINDOW_SIZE;

                while (pos != -1 && attempts < MAX_CHAIN) {
                    int dist = (wp - pos) & WINDOW_MASK;
                    if (dist == 0 || dist > w_limit) break;

                    if (window[pos] == src[si]) {
                        int ml = 0;
                        if (dist >= max_m) {
                            /* 无重叠: 直接比较窗口和源 */
                            while (ml < max_m &&
                                   window[(pos + ml) & WINDOW_MASK] == src[si + ml])
                                ml++;
                        } else {
                            /* 可能重叠: 模拟逐字节拷贝
                             * 解压器每读一字节就写一字节到wp,
                             * 当 ml >= dist 时读到的是刚写入的数据 */
                            while (ml < max_m) {
                                unsigned char expect;
                                if (ml < dist) {
                                    expect = window[(pos + ml) & WINDOW_MASK];
                                } else {
                                    /* 重叠区: 实际读到的是 src[si + ml - dist] */
                                    expect = src[si + (ml % dist)];
                                }
                                if (expect != src[si + ml]) break;
                                ml++;
                            }
                        }

                        if (ml >= MIN_MATCH && ml > best_len) {
                            best_len = ml;
                            best_off = pos;
                            if (best_len == max_m) break;
                        }
                    }
                    pos = chain_tbl[pos];
                    attempts++;
                }
            }

            if (best_len >= MIN_MATCH) {
                flag_byte |= mask;
                int ref = (best_off << 4) | ((best_len - 3) & 0x0F);
                dst[di++] = ref & 0xFF;
                dst[di++] = (ref >> 8) & 0xFF;
                for (int j = 0; j < best_len; j++) {
                    if (si + 1 < src_len) {
                        int h2 = hash2(src[si], src[si+1]);
                        chain_tbl[wp] = head_tbl[h2];
                        head_tbl[h2] = wp;
                    }
                    window[wp] = src[si++];
                    wp = (wp + 1) & WINDOW_MASK;
                    written++;
                }
            } else {
                if (si + 1 < src_len) {
                    int h2 = hash2(src[si], src[si+1]);
                    chain_tbl[wp] = head_tbl[h2];
                    head_tbl[h2] = wp;
                }
                dst[di++] = src[si];
                window[wp] = src[si++];
                wp = (wp + 1) & WINDOW_MASK;
                written++;
            }
            mask >>= 1;
        }
        dst[flag_pos] = (unsigned char)flag_byte;
    }
    return di;
}
