#!/usr/bin/env python3
"""
pmail_dat_tool.py - Overflow/ピュアメール DAT封包 解包/封包工具

格式说明:
  DAT文件结构 (SCRIPT.DAT / GRAPHIC.DAT / SOUND.DAT / VOICE.DAT):
    [子文件数据区 (LZSS压缩)]
    [索引表 (LZSS压缩)]
    [尾部 8 字节: ~index_comp_size(u32LE) + ~index_decomp_size(u32LE)]

  索引条目 (0x20 字节/条目):
    +0x00  2B  文件ID (ushort LE)
    +0x02  1B  压缩标志 (非0 = LZSS压缩)
    +0x03  1B  类型标志 (通常为 0x01)
    +0x04 16B  文件名 (ASCII, \0填充)
    +0x14  4B  数据偏移 (u32LE, 相对文件起始)
    +0x18  4B  压缩后大小 (u32LE)
    +0x1C  4B  解压后大小 (u32LE)

  LZSS变种:
    - 4KB 滑动窗口, 初始写入位置 0xFEE, 窗口初始化为 0x00
    - Flag 位从 MSB→LSB 消费 (0x80, 0x40, ..., 0x01)
    - bit=0: literal (读1字节)
    - bit=1: match (读2字节LE, 高12位=回溯偏移, 低4位+3=匹配长度)

用法:
  python pmail_dat_tool.py unpack SCRIPT.DAT [output_dir]
  python pmail_dat_tool.py pack   input_dir  SCRIPT_NEW.DAT
  python pmail_dat_tool.py list   SCRIPT.DAT
"""

import struct
import sys
import os
import json
import ctypes

# ============================================================
# C 加速模块 (可选, 自动 fallback 到纯 Python)
# ============================================================
_c_lib = None
_script_dir = os.path.dirname(os.path.abspath(__file__))
_so_path = os.path.join(_script_dir, 'lzss_fast.so')
if os.path.exists(_so_path):
    try:
        _c_lib = ctypes.CDLL(_so_path)
        _c_lib.lzss_decompress.argtypes = [
            ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        _c_lib.lzss_decompress.restype = ctypes.c_int
        _c_lib.lzss_compress.argtypes = [
            ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        _c_lib.lzss_compress.restype = ctypes.c_int
        print("[INFO] Using C-accelerated LZSS (lzss_fast.so)")
    except Exception as e:
        print(f"[WARN] Failed to load lzss_fast.so: {e}, using pure Python")
        _c_lib = None
else:
    print("[INFO] lzss_fast.so not found, using pure Python LZSS")

# ============================================================
# LZSS 解压
# ============================================================
def lzss_decompress(data, decomp_size):
    """LZSS解压 (Overflow引擎变种)"""
    if _c_lib is not None:
        src = bytes(data)
        dst = ctypes.create_string_buffer(decomp_size)
        n = _c_lib.lzss_decompress(src, len(src), dst, decomp_size)
        return dst.raw[:n]
    return _lzss_decompress_py(data, decomp_size)

def _lzss_decompress_py(data, decomp_size):
    window = bytearray(4096)
    win_pos = 0xFEE
    output = bytearray()
    src = 0

    while len(output) < decomp_size and src < len(data):
        flags = data[src]
        src += 1
        mask = 0x80

        while mask > 0 and len(output) < decomp_size and src < len(data):
            if (flags & mask) == 0:
                # literal
                b = data[src]
                src += 1
                output.append(b)
                window[win_pos] = b
                win_pos = (win_pos + 1) & 0xFFF
            else:
                # match reference
                if src + 1 >= len(data):
                    break
                lo = data[src]
                hi = data[src + 1]
                src += 2
                ref_word = lo | (hi << 8)
                back_offset = ref_word >> 4       # 高12位
                match_len = (ref_word & 0x0F) + 3  # 低4位 + 3

                for j in range(match_len):
                    if len(output) >= decomp_size:
                        break
                    b = window[(back_offset + j) & 0xFFF]
                    output.append(b)
                    window[win_pos] = b
                    win_pos = (win_pos + 1) & 0xFFF

            mask >>= 1

    return bytes(output[:decomp_size])


# ============================================================
# LZSS 压缩
# ============================================================
def lzss_compress(data):
    """LZSS压缩 (Overflow引擎变种) - 自动选择C加速或纯Python"""
    if _c_lib is not None:
        src = bytes(data)
        # 最坏情况: 每字节一个literal + flag开销 ≈ src*2
        dst_max = len(src) * 2 + 1024
        dst = ctypes.create_string_buffer(dst_max)
        n = _c_lib.lzss_compress(src, len(src), dst, dst_max)
        return dst.raw[:n]
    return _lzss_compress_py(data)

def _lzss_compress_py(data):
    """LZSS压缩 (Overflow引擎变种) - 哈希链加速"""
    WINDOW_SIZE = 4096
    MAX_MATCH = 18   # 0xF + 3
    MIN_MATCH = 3
    HASH_SIZE = 4096

    window = bytearray(WINDOW_SIZE)
    win_pos = 0xFEE
    output = bytearray()
    src = 0
    data_len = len(data)

    # 哈希链: head[hash] = 最近写入该hash的窗口位置, chain[pos] = 前一个同hash位置
    head = [-1] * HASH_SIZE
    chain = [-1] * WINDOW_SIZE

    def hash2(a, b):
        return ((a << 4) ^ b) & (HASH_SIZE - 1)

    # 初始化窗口位置 (0xFEE 之前都是0，不需要哈希)
    written = 0  # 已写入窗口的总字节数

    while src < data_len:
        flag_byte = 0
        flag_pos = len(output)
        output.append(0)
        mask = 0x80

        while mask > 0 and src < data_len:
            best_offset = 0
            best_length = 0
            max_match = min(MAX_MATCH, data_len - src)

            if max_match >= MIN_MATCH:
                h = hash2(data[src], data[src + 1] if src + 1 < data_len else 0)
                pos = head[h]
                attempts = 0
                max_attempts = 128  # 限制搜索深度

                while pos != -1 and attempts < max_attempts:
                    # 检查该位置是否在有效窗口范围内
                    dist = (win_pos - pos) & 0xFFF
                    if dist == 0 or dist > (min(written, WINDOW_SIZE)):
                        break

                    match_len = 0
                    while match_len < max_match:
                        if window[(pos + match_len) & 0xFFF] != data[src + match_len]:
                            break
                        match_len += 1

                    if match_len >= MIN_MATCH and match_len > best_length:
                        best_length = match_len
                        best_offset = pos
                        if best_length == max_match:
                            break

                    pos = chain[pos]
                    attempts += 1

            if best_length >= MIN_MATCH:
                flag_byte |= mask
                len_code = best_length - 3
                ref_word = (best_offset << 4) | (len_code & 0x0F)
                output.append(ref_word & 0xFF)
                output.append((ref_word >> 8) & 0xFF)
                for j in range(best_length):
                    # 更新哈希链
                    if src + 1 < data_len:
                        h2 = hash2(data[src], data[src + 1])
                        chain[win_pos] = head[h2]
                        head[h2] = win_pos
                    window[win_pos] = data[src]
                    win_pos = (win_pos + 1) & 0xFFF
                    written += 1
                    src += 1
            else:
                b = data[src]
                if src + 1 < data_len:
                    h2 = hash2(data[src], data[src + 1] if src + 1 < data_len else 0)
                    chain[win_pos] = head[h2]
                    head[h2] = win_pos
                window[win_pos] = b
                output.append(b)
                win_pos = (win_pos + 1) & 0xFFF
                written += 1
                src += 1

            mask >>= 1

        output[flag_pos] = flag_byte

    return bytes(output)


# ============================================================
# 索引解析
# ============================================================
ENTRY_SIZE = 0x20

def parse_index(dat_path):
    """从DAT文件尾部读取并解压索引表"""
    with open(dat_path, 'rb') as f:
        file_size = f.seek(0, 2)

        # 读取尾部8字节
        f.seek(-8, 2)
        tail = f.read(8)
        raw_comp, raw_decomp = struct.unpack('<II', tail)
        idx_comp_size = (~raw_comp) & 0xFFFFFFFF
        idx_decomp_size = (~raw_decomp) & 0xFFFFFFFF
        entry_count = idx_decomp_size >> 5

        # 读取压缩索引
        idx_offset = file_size - 8 - idx_comp_size
        f.seek(idx_offset)
        idx_comp = f.read(idx_comp_size)

    # 解压索引
    idx_data = lzss_decompress(idx_comp, idx_decomp_size)
    assert len(idx_data) == idx_decomp_size, \
        f"Index decompress size mismatch: {len(idx_data)} != {idx_decomp_size}"

    entries = []
    for i in range(entry_count):
        raw = idx_data[i * ENTRY_SIZE:(i + 1) * ENTRY_SIZE]
        file_id = struct.unpack_from('<H', raw, 0x00)[0]
        is_compressed = raw[0x02]
        type_flag = raw[0x03]
        name = raw[0x04:0x14].split(b'\x00')[0].decode('ascii', errors='replace')
        offset = struct.unpack_from('<I', raw, 0x14)[0]
        comp_size = struct.unpack_from('<I', raw, 0x18)[0]
        decomp_size = struct.unpack_from('<I', raw, 0x1C)[0]
        entries.append({
            'index': i,
            'file_id': file_id,
            'is_compressed': is_compressed,
            'type_flag': type_flag,
            'name': name,
            'offset': offset,
            'comp_size': comp_size,
            'decomp_size': decomp_size,
            'raw_header': raw[:4].hex(),
        })

    return entries, idx_offset


# ============================================================
# unpack
# ============================================================
def cmd_unpack(dat_path, output_dir):
    entries, idx_offset = parse_index(dat_path)
    os.makedirs(output_dir, exist_ok=True)

    # 保存元信息供 repack 使用
    meta = []

    with open(dat_path, 'rb') as f:
        for e in entries:
            name = e['name']
            if not name:
                meta.append(e)
                continue

            f.seek(e['offset'])
            if e['is_compressed']:
                comp_data = f.read(e['comp_size'])
                file_data = lzss_decompress(comp_data, e['decomp_size'])
                if len(file_data) != e['decomp_size']:
                    print(f"  WARNING: {name} decomp size mismatch "
                          f"({len(file_data)} != {e['decomp_size']})")
            else:
                file_data = f.read(e['decomp_size'])

            out_path = os.path.join(output_dir, name)
            with open(out_path, 'wb') as out:
                out.write(file_data)

            meta.append(e)
            print(f"  [{e['index']:3d}] {name:20s}  "
                  f"comp={e['comp_size']:6d}  decomp={e['decomp_size']:6d}")

    # 保存 meta.json
    meta_path = os.path.join(output_dir, '_meta.json')
    with open(meta_path, 'w', encoding='utf-8') as mf:
        json.dump(meta, mf, indent=2, ensure_ascii=False)

    print(f"\nExtracted {sum(1 for e in entries if e['name'])} files to {output_dir}")
    print(f"Metadata saved to {meta_path}")


# ============================================================
# pack
# ============================================================
def cmd_pack(input_dir, dat_path):
    meta_path = os.path.join(input_dir, '_meta.json')
    if not os.path.exists(meta_path):
        print(f"ERROR: {meta_path} not found. Run 'unpack' first.")
        sys.exit(1)

    with open(meta_path, 'r', encoding='utf-8') as mf:
        meta = json.load(mf)

    data_buf = bytearray()
    new_entries = []

    for e in meta:
        name = e['name']
        if not name:
            # 空条目保持原样
            new_entries.append(e)
            continue

        file_path = os.path.join(input_dir, name)
        if not os.path.exists(file_path):
            print(f"  WARNING: {name} not found, skipping")
            new_entries.append(e)
            continue

        with open(file_path, 'rb') as f:
            file_data = f.read()

        decomp_size = len(file_data)
        new_offset = len(data_buf)

        if e['is_compressed']:
            comp_data = lzss_compress(file_data)
            comp_size = len(comp_data)
            data_buf.extend(comp_data)
        else:
            comp_size = 0
            data_buf.extend(file_data)

        ne = dict(e)
        ne['offset'] = new_offset
        ne['comp_size'] = comp_size
        ne['decomp_size'] = decomp_size
        new_entries.append(ne)

        ratio = comp_size / decomp_size * 100 if decomp_size > 0 and e['is_compressed'] else 0
        print(f"  [{ne['index']:3d}] {name:20s}  "
              f"comp={comp_size:6d}  decomp={decomp_size:6d}  "
              f"({ratio:.1f}%)")

    # 构建索引表
    entry_count = len(new_entries)
    idx_decomp_size = entry_count * ENTRY_SIZE
    idx_buf = bytearray(idx_decomp_size)

    for i, ne in enumerate(new_entries):
        base = i * ENTRY_SIZE
        struct.pack_into('<H', idx_buf, base + 0x00, ne['file_id'])
        idx_buf[base + 0x02] = ne['is_compressed']
        idx_buf[base + 0x03] = ne['type_flag']
        name_bytes = ne['name'].encode('ascii')[:16]
        idx_buf[base + 0x04:base + 0x04 + len(name_bytes)] = name_bytes
        struct.pack_into('<I', idx_buf, base + 0x14, ne['offset'])
        struct.pack_into('<I', idx_buf, base + 0x18, ne['comp_size'])
        struct.pack_into('<I', idx_buf, base + 0x1C, ne['decomp_size'])

    # 压缩索引表
    idx_comp = lzss_compress(bytes(idx_buf))
    idx_comp_size = len(idx_comp)

    # 尾部8字节: ~comp_size + ~decomp_size
    tail = struct.pack('<II',
                       (~idx_comp_size) & 0xFFFFFFFF,
                       (~idx_decomp_size) & 0xFFFFFFFF)

    # 写入文件
    with open(dat_path, 'wb') as f:
        f.write(data_buf)
        f.write(idx_comp)
        f.write(tail)

    print(f"\nPacked {sum(1 for e in new_entries if e['name'])} files to {dat_path}")
    print(f"  Data:  {len(data_buf)} bytes")
    print(f"  Index: {idx_comp_size} bytes (decomp {idx_decomp_size})")
    print(f"  Total: {len(data_buf) + idx_comp_size + 8} bytes")


# ============================================================
# list
# ============================================================
def cmd_list(dat_path):
    entries, idx_offset = parse_index(dat_path)
    file_size = os.path.getsize(dat_path)

    print(f"DAT file: {dat_path}")
    print(f"File size: {file_size} bytes")
    print(f"Index at: 0x{idx_offset:X}")
    print(f"Entries: {len(entries)}")
    print()
    print(f"{'#':>4s}  {'ID':>5s}  {'C':>1s} {'T':>1s}  {'Name':20s}  "
          f"{'Offset':>10s}  {'CompSize':>9s}  {'DecompSize':>10s}  {'Ratio':>6s}")
    print("-" * 85)

    total_comp = 0
    total_decomp = 0
    for e in entries:
        if not e['name']:
            continue
        ratio = e['comp_size'] / e['decomp_size'] * 100 if e['decomp_size'] > 0 and e['is_compressed'] else 0
        total_comp += e['comp_size'] if e['is_compressed'] else e['decomp_size']
        total_decomp += e['decomp_size']
        print(f"{e['index']:4d}  {e['file_id']:5d}  {e['is_compressed']:1d} {e['type_flag']:1d}  "
              f"{e['name']:20s}  0x{e['offset']:08X}  {e['comp_size']:9d}  "
              f"{e['decomp_size']:10d}  {ratio:5.1f}%")

    print("-" * 85)
    overall = total_comp / total_decomp * 100 if total_decomp > 0 else 0
    print(f"Total: {total_comp} / {total_decomp} bytes ({overall:.1f}%)")


# ============================================================
# main
# ============================================================
def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == 'unpack':
        dat_path = sys.argv[2]
        output_dir = sys.argv[3] if len(sys.argv) > 3 else os.path.splitext(dat_path)[0] + '_out'
        cmd_unpack(dat_path, output_dir)

    elif cmd == 'pack':
        input_dir = sys.argv[2]
        dat_path = sys.argv[3] if len(sys.argv) > 3 else 'SCRIPT_NEW.DAT'
        cmd_pack(input_dir, dat_path)

    elif cmd == 'list':
        cmd_list(sys.argv[2])

    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)
        sys.exit(1)


if __name__ == '__main__':
    main()
